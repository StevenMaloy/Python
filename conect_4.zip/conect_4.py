# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 09:33:31 2020

@author: Steven Maloy
"""
import numpy as np
import random as rand

board = np.zeros((10,8))

def game(play,turn,victory):
    fit = 0
    """ filling the board """
    i = 1
    #board[0,play] = turn
    while(fit != 1):
         if((i < 9) & ((board[i,play]) == 0)):
             board[i,play] = turn
             board[(i-1),play] = 0
             i +=1
         elif(i==1):
             fit = 1 
             turn -= 1
             board[(i-1),play] = 0
             print('invalid placement try again')
             return(victory, turn)
         else:
            fit= 1
            
    """ check for victory """
    
    for y in range(8):
        for x in range(10):
            if(((board[x,y])==turn) & (x<7)):
                if( ((board[x,y])==turn) &  ((board[(x+1),y])==turn) & ((board[(x+2),y])==turn) & ((board[(x+3),y])==turn)):
                    print(board)
                    victory = 1
                    return(victory, turn)
            if(((board[x,y])==turn) & (y<5)):       
                if( ((board[x,y])==turn) & ((board[x,(y+1)])==turn) & ((board[x,(y+2)])==turn) & ((board[x,(y+3)])==turn)):
                    print(board)
                    victory = 1
                    return(victory, turn)
            if(((board[x,y])==turn) & ((y<5)&(x<7))):
                if( ((board[x,y])==turn) & ((board[(x+1),(y+1)])==turn) & ((board[(x+2),(y+2)])==turn) & ((board[(x+3),(y+3)])==turn)):
                    print(board)
                    victory = 1
                    return(victory, turn)
            if(((board[x,y])==turn) & ((y<5)&(x>3))):
                if( ((board[x,y])==turn) & ((board[(x-1),(y+1)])==turn) & ((board[(x-2),(y+2)])==turn) & ((board[(x-3),(y+3)])==turn)):
                    print(board)
                    victory = 1
                    return(victory, turn)
               
    return(victory, turn)

def connect4():
    mode = gamemode()
    turn = 0
    victory = 0
    while(victory != 1):
        skip = 0
        """ switching turns """   
        if(turn == 1):
            turn = 2
        else:
            turn = 1
            
            """  making players/computer turn """
        print('\n',board)
        if((mode == 2) & (turn == 2)):
            player = int(rand.triangular(low = 0,high = 7))
            skip = 1
        play = 0
        while((play != 1) & (skip != 1)):
            player = int(input('choose slot 0-7: ',))
            if((0 <= player) & (player <= 7 )):
                play = 1
            else:
                print('outside of range')
                    
                """ sending play to game """     
        
        victory,turn = game(player,turn,victory)
    print('Victory for player' ,turn)


def gamemode():
    print('gamemode Player vs player is 1')
    print('gamemode Player vs computer is 2')
    gamemode = int(input('input gamemode number: ',))
    return(gamemode)
    
connect4()



