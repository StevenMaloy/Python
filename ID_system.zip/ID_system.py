# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 11:15:22 2020

@author: Steven Maloy
"""
#import numpy as np
import random as rand
import json

""" global veriables """
ID_to_name = {}
list_of_IDs = []
""" make a file if one doesn't exist """
try:
    f = open("IDdictionary.txt","x")
    f.close()
except:
    print("file exists")
    
""" make the dictionary the same as text file """

f = open("IDdictionary.txt","r")
for line in f:
    line = line.replace("'",'"')
    print(line)
    ID_to_name = json.loads(line)
f.close()

""" give a unique id for a name/person """

def ID(name):
    dont_have_spot = 1
    while(dont_have_spot == 1):
        Randome_Number =  int(rand.triangular(low = 100000,high = 999999))
        list_of_IDs = ID_to_name.keys()
        if(len(list_of_IDs)==0):
            ID_to_name.update({str(Randome_Number):name})
            dont_have_spot = 0
            return(Randome_Number)
        print(len(list_of_IDs))
        for i in list_of_IDs:
            print(i)
            if(Randome_Number != i):
                ID_to_name.update({str(Randome_Number):name})
                dont_have_spot = 0
                return(Randome_Number)

""" write the name of new person """

def new_member():
    name = str(input("Type your name here: "))
    get_ID = ID(name)
    print(get_ID)
    f = open("IDdictionary.txt","w")
    f.write( str(dict(ID_to_name)) )
    f.close()
new_member()










